import pandas as pd
import numpy as np


def get_avg_consumo(df):

    ## renomeia colunas de consumo de "MES_n" para "CONS_ano_mes"
    consumo_cols = [col for col in df.columns if col.startswith("MES_")]
    df[consumo_cols] = df[consumo_cols].astype(float)
    
    df["SUM_CONSUMO"] = df[consumo_cols].sum(axis=1)
    df["COUNT_CONSUMO"] = df[consumo_cols].count(axis=1)

    df["AVG_CONSUMO"] = round(df["SUM_CONSUMO"]/df["COUNT_CONSUMO"], 2)

    df = df.drop(columns=["SUM_CONSUMO","COUNT_CONSUMO"]+consumo_cols, errors="ignore")

    return df

## tratamento para variaveis categoricas
def encode_and_bind(original_dataframe, feature_to_encode):

    dummies = pd.get_dummies(original_dataframe[[feature_to_encode]], prefix=[feature_to_encode])
    res = pd.concat([original_dataframe.drop(columns=[feature_to_encode]), dummies], axis=1)

    return res

def encode_features(df: pd.DataFrame, features_to_encode: list):
    for feature in features_to_encode:
        df = encode_and_bind(df, feature)

    return df

def get_avg_regiao(df: pd.DataFrame, lig_col:str, regiao_col:str, distribuidora: str):

    if distribuidora == 'Neoenergia Elektro':
        regiao = "UTD"
    else:
        regiao = "BAIRRO"

    avg_std_regiao = (df[df[lig_col] > 0]
        .groupby(
            by=[regiao_col]).agg({
                lig_col:['mean', 'std']})
                .reset_index(level=regiao_col, col_level=1)
                .droplevel(0, axis=1)
                .rename({"mean":f"AVG_QTD_LIG_{regiao}",
                            "std":f"STD_QTD_LIG_{regiao}"}, axis=1))

    df = df.merge(avg_std_regiao, how="left", on=regiao_col)

    for col in [f"AVG_QTD_LIG_{regiao}",f"STD_QTD_LIG_{regiao}"]:
        df[col] = round(df[col].fillna(0), 2)

    df[f"FLAG_LIGOU_MAIS_QUE_AVG_{regiao}"] = np.where(df[lig_col] > df[f"AVG_QTD_LIG_{regiao}"], 1, 0)
    df.loc[df[regiao_col].isna(), f"FLAG_LIGOU_MAIS_QUE_AVG_{regiao}"] = 0

    return df

def get_prop_regiao(df: pd.DataFrame, lig_col:str, falta_energia_col:str,
                    regiao_col:str, distribuidora: str):
    
    if distribuidora == 'Neoenergia Elektro':
        regiao = "UTD"
    else:
        regiao = "BAIRRO"

    df["PROP_LIG_OCOR_12M"] = df[lig_col]/df[falta_energia_col]
    df.loc[(df[lig_col] == 0) | (df[falta_energia_col] == 0), "PROP_LIG_OCOR_12M"] = 0

    prop_regiao = (df[(df[lig_col] > 0) & (df[falta_energia_col] > 0)]
        .groupby(
            by=[regiao_col]).agg({
                lig_col:"sum",
                falta_energia_col:"sum"
                })
                .reset_index())

    prop_regiao[f"PROP_LIG_OCOR_12M_{regiao}"] = prop_regiao[lig_col]/prop_regiao[falta_energia_col]
    prop_regiao.drop(columns=[lig_col, falta_energia_col], errors="ignore", inplace=True)

    df = df.merge(prop_regiao, how="left", on=regiao_col)

    df[f"FLAG_PROP_12M_MAIOR_{regiao}"] = np.where(
        df["PROP_LIG_OCOR_12M"] > df[f"PROP_LIG_OCOR_12M_{regiao}"], 1, 0)
    df.loc[
        (df[regiao_col].isna()) |
        (df[lig_col] == 0) |
        (df[falta_energia_col] == 0), f"FLAG_PROP_12M_MAIOR_{regiao}"] = 0

    return df
