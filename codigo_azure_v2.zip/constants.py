from datetime import datetime
from dateutil.relativedelta import relativedelta

########################################################################

subscription_id = '673e0b25-0296-4447-85ee-1addfd09ca0d'
resource_group = 'rg-conexaodigital-dev'
workspace_name = 'aml-conexaodigital-dev'

# workspace = Workspace(subscription_id, resource_group, workspace_name)
# datastore = workspace.get_default_datastore()

########################################################################

today = datetime(year=2023, month=1, day=30)
# today = datetime.now()
today -= relativedelta(days=1)

distribuidora = "Neoenergia Pernambuco"

data_1m = today - relativedelta(months=1)
data_3m = today - relativedelta(months=3)
data_12m = today - relativedelta(months=12)

sample = False
sample_size = 0

dist_dict: dict =  {'NEKT':'Neoenergia Elektro',
    'NPER':'Neoenergia Pernambuco',
    'NCSR':'Neoenergia Cosern',
    'NCLB':'Neoenergia Coelba',
    'ELEKTRO':'Neoenergia Elektro',
    'PERNAMBUCO':'Neoenergia Pernambuco',
    'COSERN':'Neoenergia Cosern',
    'COELBA':'Neoenergia Coelba',
    'ELK':'Neoenergia Elektro',
    'PE':'Neoenergia Pernambuco',
    'CSR':'Neoenergia Cosern',
    'CLB':'Neoenergia Coelba'}
