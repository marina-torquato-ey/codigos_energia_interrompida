import pandas as pd
import numpy as np
from dateutil.relativedelta import relativedelta


def treat_cols(df: pd.DataFrame, str_cols: list, date_cols: list,
               formato: str = '', uc_col: str = 'UC_CONTACONTRATO'):
    for col in df.columns:
        df.loc[df[col] == "", col] = np.nan

    if formato == '':
        formato = '%Y-%m-%d'
    if len(date_cols) > 0:
        for col in date_cols:
            df[col] = pd.to_datetime(df[col], format= formato)

    if len(str_cols) > 0:
        for col in str_cols:
            df[col] = df[col].str.strip()

    df.loc[df[uc_col].notnull(), uc_col] = df.loc[df[uc_col].notnull(), uc_col].astype(int).astype(str)

    return df

def filter_dist(df: pd.DataFrame, distribuidora: str, dist_dict: dict, col_dist: str = "DISTRIBUIDORA"):

    if (col_dist in df.columns) and (df[col_dist].unique() not in list(set(dist_dict.values()))):
        df[col_dist] = df[col_dist].map(dist_dict)

    if "EMPRESA" in df.columns:
        df[col_dist] = df["EMPRESA"].map(dist_dict)

    df = df[df[col_dist] == distribuidora].reset_index(drop=True)

    return df

def drop_constant_cols(df, dist_col='DISTRIBUIDORA'):
    col_const = []
    for col in df.columns:
        if ((len(df[col].fillna("null_value").unique()) == 1) and (col != dist_col)):
            col_const.append(col)

    return df.drop(columns=col_const, errors="ignore")

def groupby_df(df: pd.DataFrame, groupby_cols: list, cols_dict: dict):

    grouped_df = df.copy()

    grouped_df = grouped_df.groupby(
        by=groupby_cols, as_index=False).agg(cols_dict)

    grouped_df = (grouped_df
        .drop_duplicates()
        .reset_index(drop=True))

    return grouped_df

def create_flags_aux(df, years, distribuidora):
    
    outono = []
    verao = []
    inverno = []
    primavera = []
    for year in years:
        primavera += pd.date_range(start=f"{year}-09-23", end=f"{year}-12-21").tolist()
        verao += pd.date_range(start=f"{year}-12-22", end=f"{year}-12-31").tolist()
        verao += pd.date_range(start=f"{year}-01-01", end=f"{year}-03-20").tolist()
        outono += pd.date_range(start=f"{year}-03-21", end=f"{year}-06-20").tolist()
        inverno += pd.date_range(start=f"{year}-06-21", end=f"{year}-09-22").tolist()

    ## ESTACOES
    estacoes = {"OUTONO": outono, "INVERNO": inverno, "PRIMAVERA": primavera, "VERAO": verao}
    for key, value in estacoes.items():
        df[f'FLAG_{key}'] = np.where(pd.to_datetime(df['DATA'].dt.date).isin(value), 1, 0)


    ## FÉRIAS ESCOLARES
    ferias_list = [1, 7, 12]

    df["FLAG_FERIAS_ESCOLARES"] = 0
    df.loc[df["MES_EVENTO"].isin(ferias_list), "FLAG_FERIAS_ESCOLARES"] = 1

    ## PERÍODO DE CHUVA
    seco = list(np.arange(5, 12))
    umido = list(np.arange(1, 5)) + [12]

    df.loc[df["MES_EVENTO"].isin(seco), "FLAG_PERIODO_SECO"] = 1
    df.loc[df["MES_EVENTO"].isin(umido), "FLAG_PERIODO_UMIDO"] = 1
    for col in ["FLAG_PERIODO_SECO", "FLAG_PERIODO_UMIDO"]:
        df[col] = df[col].fillna(0).astype(int)


    df["TEMPO_PREVISAO_LIGACAO"] = round(
        (df["DATETIME_LIGACAO"] - df["DATETIME_PREVISAO"]).dt.total_seconds()/60, 2).fillna(0)
    df["LIGOU_ANTES_PREVISAO"] = 0
    if distribuidora != 'Neoenergia Elektro':
        df.loc[(df["RECEBEU_SMS_E_LIGOU"] == 1) & (df["TEMPO_PREVISAO_LIGACAO"] < 0), "LIGOU_ANTES_PREVISAO"] = 1

    return df

def find_max_date(df: pd.DataFrame, uc_col:str, date_col: str, qtd_historico: int):

    max_data_df = df.groupby(uc_col, as_index=False).agg({
        date_col:"max"})

    max_data_df[f"{date_col}_{qtd_historico}M"] = max_data_df[date_col] - relativedelta(months = qtd_historico)

    df = df.merge(max_data_df[[uc_col, f"{date_col}_{qtd_historico}M"]], how="left", on=uc_col)

    df["HISTORICO_ANTIGO"] = np.where(df[f"{date_col}_{qtd_historico}M"] > df[date_col], 1, 0)

    df = (df[df["HISTORICO_ANTIGO"] == 0]
        .drop(columns=["HISTORICO_ANTIGO",f"{date_col}_{qtd_historico}M"], errors="ignore")
        .reset_index(drop=True)
        )
    
    return df

def create_final_flags(df, distribuidora):
    flags = ["RECEBEU_SMS_E_LIGOU", "RECEBEU_SMS_NAO_LIGOU", "NAO_RECEBEU_SMS_LIGOU",
    "NAO_RECEBEU_SMS_NAO_LIGOU"]

    df[flags] = 0

    ## RECEBEU_SMS_E_LIGOU: faltou energia, NEO mandou sms, cliente entrou em contato
    df.loc[
        (df["FLAG_CONTATO_NEO"] == 1) &
        (df["QTD_LIGACOES"] > 0), "RECEBEU_SMS_E_LIGOU"] = 1

    ## RECEBEU_SMS_NAO_LIGOU: faltou energia, NEO mandou sms, cliente não entrou em contato
    df.loc[
        (df["FLAG_CONTATO_NEO"] == 1) &
        (df["QTD_LIGACOES"] == 0), "RECEBEU_SMS_NAO_LIGOU"] = 1

    ## NAO_RECEBEU_SMS_LIGOU: faltou ou não energia, NEO não mandou sms, cliente entrou em contato
    df.loc[
        (df["FLAG_CONTATO_NEO"] == 0) &
        (df["QTD_LIGACOES"] > 0), "NAO_RECEBEU_SMS_LIGOU"] = 1

    ## NAO_RECEBEU_SMS_NAO_LIGOU: faltou ou não energia, NEO não mandou sms, cliente não entrou em contato
    df.loc[
        (df["FLAG_CONTATO_NEO"] == 0) &
        (df["QTD_LIGACOES"] == 0), "NAO_RECEBEU_SMS_NAO_LIGOU"] = 1

    df = df[
        ["UC", "DISTRIBUIDORA", "DATA"] +
        [col for col in df.columns if col not in ["UC", "DISTRIBUIDORA", "DATA"]]]
    
    df = (df
        .pipe(create_flags_aux, [2018, 2019, 2020, 2021, 2022, 2023], distribuidora)
        .drop(
            ["HORA", "DIF_HR_DATAS", "MES_EVENTO", "DIA_DA_SEMANA", "DAY_TYPE", "FLAG_CELULAR",
                "TEMPO_PREVISAO_LIGACAO"],
            axis=1, errors = "ignore")
        )

    return df