import pandas as pd
import numpy as np

from constants import distribuidora, dist_dict
from functions_aux import filter_dist, groupby_df, treat_cols


def filter_df_hist(df, distribuidora):

    if distribuidora == 'Neoenergia Elektro':
        df["DATA_RECLAMACAO"] = np.where(
            df["DATA_CRIACAO"] > df["DATA_PREVISAO"], df["DATA_PREVISAO"], df["DATA_CRIACAO"])

    df = (df
        .dropna(how='all', axis='columns')
        .sort_values(by=["UC_CONTACONTRATO","FLAG_CONTATO_NEO"], ascending=[True, False])
        .drop_duplicates(
            subset=['SERVICO', 'DISTRIBUIDORA', 'UC_CONTACONTRATO', 'NR_CELULAR',
                    'DATA_RECLAMACAO', 'DATA_PREVISAO'],
            keep="first"))

    df["DATA_OCORRENCIA"] = df["DATA_RECLAMACAO"].dt.date

    return df.sort_values(by=["UC_CONTACONTRATO", "DATA_RECLAMACAO"], ascending=[True, False]).reset_index(drop=True)

def create_flags_hist(df, date_col, data_1m, data_3m, data_12m):
    ## teve falta de energia no ultimo mes / ultimo ano
    df[["CONTATO_NEO_ULTIMO_EVENTO", "QTD_FALTA_ENERGIA_1M", "QTD_FALTA_ENERGIA_3M", "QTD_FALTA_ENERGIA_12M",
        "QTD_CONTATO_NEO_1M", "QTD_CONTATO_NEO_3M", "QTD_CONTATO_NEO_12M"]] = 0

    df.loc[(df[date_col] >= data_1m), "QTD_FALTA_ENERGIA_1M"] = 1
    df.loc[(df[date_col] >= data_3m), "QTD_FALTA_ENERGIA_3M"] = 1
    df.loc[(df[date_col] >= data_12m), "QTD_FALTA_ENERGIA_12M"] = 1

    df.loc[
        (df[date_col] == df["ULTIMO_EVENTO"]) &
        (df["FLAG_CONTATO_NEO"] == 1), "CONTATO_NEO_ULTIMO_EVENTO"] = 1

    df.loc[
        (df[date_col] >= data_1m) &
        (df["FLAG_CONTATO_NEO"] == 1), "QTD_CONTATO_NEO_1M"] = 1
    df.loc[
        (df[date_col] >= data_3m) &
        (df["FLAG_CONTATO_NEO"] == 1), "QTD_CONTATO_NEO_3M"] = 1
    df.loc[
        (df[date_col] >= data_12m) &
        (df["FLAG_CONTATO_NEO"] == 1), "QTD_CONTATO_NEO_12M"] = 1

    return df

def find_celular_valido(df):

    df_cel = df[["UC_CONTACONTRATO","DISTRIBUIDORA","NR_CELULAR","FLAG_CONTATO_NEO","DATA_RECLAMACAO"]]
    df_cel = (df_cel
        .assign(
            LEN_NR_CELULAR = df_cel["NR_CELULAR"].str.len(),
            NR_CELULAR = "55" + df_cel["NR_CELULAR"].astype(str))
        .sort_values(by=["FLAG_CONTATO_NEO","DATA_RECLAMACAO"], ascending=False)
        .reset_index(drop=True)
        )

    df_cel = (df_cel[df_cel["LEN_NR_CELULAR"] == 11][["UC_CONTACONTRATO","DISTRIBUIDORA","NR_CELULAR"]]
        .drop_duplicates(keep="first")
        .reset_index(drop=True))
    
    return df_cel

def find_total_contato(df):

    total_contato = (df
                        .pipe(groupby_df,
                            ["UC_CONTACONTRATO","DISTRIBUIDORA"],
                            {'FLAG_CONTATO_NEO':sum,
                            'DATA_CRIACAO':'count',
                            'DATA_RECLAMACAO':'max'})
                        .rename(columns={
            "FLAG_CONTATO_NEO":"QTD_TOTAL_CONTATO_NEO",
            "DATA_CRIACAO":"QTD_FALTA_ENERGIA",
            "DATA_RECLAMACAO":"ULTIMO_EVENTO"})
                            )

    df = df.merge(
        total_contato,
        how="left",
        on=["UC_CONTACONTRATO","DISTRIBUIDORA"])
    
    return df