from functions_aux import treat_cols

def join_ocor_lig(ocorrencias, ligacoes):

    df = ocorrencias.merge(
        ligacoes,
        how="outer",
        left_on=["UC", "DATA_OCORRENCIA", "DISTRIBUIDORA"],
        right_on=["UC", "DATA_LIGACAO", "DISTRIBUIDORA"])

    df = treat_cols(df,
        str_cols=[],
        date_cols=["DATA_OCORRENCIA", "DATA_LIGACAO", "DATETIME_OCORRENCIA", 
            "DATETIME_PREVISAO", "DATETIME_LIGACAO", "ULTIMA_LIGACAO"],
        uc_col="UC")

    df["DATA"] = df["DATETIME_LIGACAO"].fillna(df["DATETIME_OCORRENCIA"])

    df = (df
        .assign(
            MES_EVENTO = df["DATA"].dt.month,
            HORA = df["DATA"].dt.hour,
            )
        )

    return df

def final_dataset(ocor_lig):

    group_cols = [col for col in ocor_lig.columns if not col.startswith("DAT")]

    for col in ["UC", "DISTRIBUIDORA", "QTD_FALTA_ENERGIA", "ULTIMA_LIGACAO", "QTD_TOTAL_LIGACOES"]:
        group_cols.remove(col)

    cols_dict = dict.fromkeys(group_cols, "sum")
    cols_dict.update(
        {"FLAG_CONTATO_NEO":"max",
        "QTD_TOTAL_CONTATO_NEO":"max",
        })

    final_df = ocor_lig.groupby(by=["UC", "DISTRIBUIDORA"], as_index=False).agg(cols_dict)

    return final_df