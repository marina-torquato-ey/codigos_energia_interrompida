import pandas as pd
import numpy as np

from functions_aux import groupby_df


def find_total_ligacao(df):

    total_ligacao = (df
                        .pipe(groupby_df,
                            ["UC","DISTRIBUIDORA"],
                            {'ANI':'count', 'DATETIME':'max'})
                        .rename(columns={
                            "ANI":"QTD_TOTAL_LIGACOES",
                            "DATETIME":"ULTIMA_LIGACAO"})
                            )

    df = df.merge(
        total_ligacao,
        how="left",
        on=["UC","DISTRIBUIDORA"])
    
    return df

def filter_df_rech(df: pd.DataFrame, rechamada_cols: list):

    df = df[rechamada_cols]
    df = (df[
            (df["SKILL"] == "FALTA ENERGIA") &
            (df["UC"].notnull()) &
            (df["UC"] != '')]
        .drop_duplicates()
        .sort_values(by=["UC","DISTRIBUIDORA","DATETIME"])
        .reset_index(drop=True))
    
    df = (df
            .assign(
        DATA_LIGACAO=df["DATETIME"].dt.date,
        ANI=df["ANI"].fillna("NA")))

    return df

def create_flags_rech(df, date_col, data_1m, data_3m, data_12m):

    df = (df
            .assign(
        QTD_LIG_1M=np.where(df[date_col] >= data_1m, 1, 0),
        QTD_LIG_3M=np.where(df[date_col] >= data_3m, 1, 0),
        QTD_LIG_12M=np.where(df[date_col] >= data_12m, 1, 0))
        )

    return df